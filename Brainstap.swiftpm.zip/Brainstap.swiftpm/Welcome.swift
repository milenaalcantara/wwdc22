//
//  Welcome.swift
//  Brainstap
//
//  Created by Milena Lima de Alcântara on 22/04/22.
//

import SwiftUI

struct Welcome: View {
    
    var body: some View {
        ZStack {
            Color(
                red: 125/255,
                green: 10/255,
                blue: 1
            ).ignoresSafeArea()
            
            VStack {
                Text("Hey")
                NavigationLink {
                    TopicList(topic: Topic.example)
                } label: {
                    Text("Go to Themes")
                        .padding()
                        .background(.purple)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                }
                .accessibilityLabel("Go to Themes")
            }
            //        .padding(.infinity)
        }
    }
}

struct Welcome_Previews: PreviewProvider {
    static var previews: some View {
        Welcome()
    }
}
//
//Text("Selecione um Tema para iniciar seu brainstorm")
//    .foregroundStyle(.secondary)
//TopicList(topic: Topic.example)
