import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            Welcome()
        }
        .navigationViewStyle(StackNavigationViewStyle())
            .navigationBarHidden(true)
    }
}
