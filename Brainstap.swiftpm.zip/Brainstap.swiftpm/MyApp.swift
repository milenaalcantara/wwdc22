import SwiftUI

@main
struct BrainstapApp: App {
    @StateObject private var topicData = TopicData()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(topicData)
        }
    }
}
