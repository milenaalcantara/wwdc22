//
//  TopicData.swift
//  Brainstap
//
//  Created by Milena Lima de Alcântara on 19/04/22.
//

import Foundation
import SwiftUI

class TopicData: ObservableObject {
//    @Published var topics: [Topic] = [
//        Topic(title: "Maya's Birthday"),
//        Topic(title: "Pagliacci"),
//        Topic(title: "Doctor's Appointment"),
//        Topic(title: "Camping Trip")
//    ]
    
    @Published var topics: [Topic] = [Topic.example]

    func delete(_ topic: Topic) {
        topics.removeAll { $0.id == topic.id }
    }
    
    func add(_ topic: Topic) {
        topics.append(topic)
    }
    
    func exists(_ topic: Topic) -> Bool {
        topics.contains(topic)
    }
    
    func choiceTopic(topic: Topic) -> Binding<[Topic]> {
        Binding<[Topic]> {
            self.topics
        } set: { topics in
            for topic in topics {
                if let index = self.topics.firstIndex(where: { $0.id == topic.id }) {
                    self.topics[index] = topic
                }
            }
        }

    }
}

//protocol Topic: String, Identifiable {
//
//    var id: String { self.rawValue }
//    var title: String { self.rawValue }
//}


//
//func sortedEvents(period: Period) -> Binding<[Event]> {
//    Binding<[Event]>(
//        get: {
//            self.events
//                .filter {
//                    switch period {
//                    case .nextSevenDays:
//                        return $0.isWithinSevenDays
//                    case .nextThirtyDays:
//                        return $0.isWithinSevenToThirtyDays
//                    case .future:
//                        return $0.isDistant
//                    case .past:
//                        return $0.isPast
//                    }
//                }
//                .sorted { $0.date < $1.date }
//        },
//        set: { events in
//            for event in events {
//                if let index = self.events.firstIndex(where: { $0.id == event.id }) {
//                    self.events[index] = event
//                }
//            }
//        }
//    )
//}
