//
//  Topic.swift
//  Brainstap
//
//  Created by Milena Lima de Alcântara on 19/04/22.
//

import Foundation


struct Topic: Identifiable, Hashable {
    var id = UUID()
    var title = ""
    var ideas: [Idea] = []
    
    static var example = Topic(
        title: "Aniversário da lulu",
        ideas: [
            Idea(text: "Balões coloridos"),
            Idea(text: "Brincadeira do túnel"),
            Idea(text: "Bolo de unicónio"),
            Idea(text: "Festa em casa"),
            Idea(text: "Alugar buffet"),
            Idea(text: "Parabéns na escola"),
            Idea(text: "Balões coloridos"),
            Idea(text: "Brincadeira do túnel"),
            Idea(text: "Bolo de unicónio"),
            Idea(text: "Festa em casa"),
            Idea(text: "Alugar buffet"),
            Idea(text: "Parabéns na escola"),
            Idea(text: "Balões coloridos"),
            Idea(text: "Brincadeira do túnel"),
            Idea(text: "Bolo de unicónio"),
            Idea(text: "Festa em casa"),
            Idea(text: "Alugar buffet"),
            Idea(text: "Parabéns na escola"),
            Idea(text: "Balões coloridos"),
            Idea(text: "Brincadeira do túnel"),
            Idea(text: "Bolo de unicónio"),
            Idea(text: "Festa em casa"),
            Idea(text: "Alugar buffet"),
            Idea(text: "Parabéns na escola"),
        ]
    )
}

//extension Topic {
//    static var topics: [Topic] =
//    [
//        Topic(title: "Aula de matemática"
////              , ideas: [
////                Idea(text: "Vídeo Aulas"),
////                Idea(text: "Ábaco"),
////                Idea(text: "campeonato de jogos"),
////                Idea(text: "Jogos de lógica")
////        ]
//        ),
//        Topic(title: "Nomes de bebê"
////              , ideas: [
////                Idea(text: "Cathy"),
////                Idea(text: "Daisy"),
////                Idea(text: "Simon"),
////                Idea(text: "Jonathan")
////        ]
//        ),
//        Topic(title: "Funday"
////              , ideas: [
////                Idea(text: "karaokê"),
////                Idea(text: "piscina"),
////        ]
//        ),
//    ]
//    
//    func add(_ topic: Topic) {
//        Topic.topics.append(topic)
//    }
//    
//    func delete(_ topic: Topic) {
//        Topic.topics.removeAll { $0.id == topic.id }
//    }
//
//}
