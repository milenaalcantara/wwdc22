//
//  TopicRow.swift
//  
//
//  Created by Milena Lima de Alcântara on 19/04/22.
//

import SwiftUI

struct TopicRow: View {
    let topic: Topic
    
    var body: some View {
        HStack {
            Text(topic.title)
                .font(.headline)
        }
        .padding(.all, 10)
        .foregroundColor(.gray)
    }
}

struct TopicRow_Previews: PreviewProvider {
    static var previews: some View {
        TopicRow(topic: Topic.example)
            .previewLayout(.fixed(width: 400, height: 60))
    }
}
