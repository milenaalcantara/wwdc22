//
//  SwiftUIView.swift
//  
//
//  Created by Milena Lima de Alcântara on 22/04/22.
//

import SwiftUI

struct BouncingView: View {
    var text: String
    @State private var bouncing = false

    var body: some View {
        ZStack {
            Text(text)
                .background(.gray)
                .foregroundColor(.white)
                .padding(10)
                .cornerRadius(20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: bouncing ? .bottom : .top)
        .animation(Animation.easeInOut(duration: 10.0).repeatForever(autoreverses: true).delay(1))
        .onAppear {
            self.bouncing.toggle()
        }
    }
}


//            .withAnimation(T##SwiftUI.Animation?, Animation.easeInOut(duration: 10.0).repeatForever(autoreverses: true))
