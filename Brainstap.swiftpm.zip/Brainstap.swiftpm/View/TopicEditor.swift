//
//  TopicEdit.swift
//  Brainstap
//
//  Created by Milena Lima de Alcântara on 20/04/22.
//

import SwiftUI

struct TopicEdit: View {
    @Binding var topic: Topic
    var isNew = false
    
    @State private var isDeleted = false
    @EnvironmentObject var topicData: TopicData
    @Environment(\.dismiss) private var dismiss
    
    @State private var topicCopy = Topic()
    @State private var isEditing = false
    
    private var isTopicDeleted: Bool {
        !topicData.exists(topic) && !isNew
    }
    
    var body: some View {
        VStack {
            TopicDetail(topic: $topicCopy, isEditing: isNew ? true : isEditing)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        if isNew {
                            Button("Cancelar") {
                                dismiss()
                            }
                        }
                    }
                    ToolbarItem {
                        Button {
                            if isNew {
                                topicData.topics.append(topicCopy)
                                dismiss()
                            } else {
                                if isEditing && !isDeleted {
                                    print("Prontinho, tema '\(topic.title)' salvo.")
                                    withAnimation {
                                        topic = topicCopy // Put edits (if any) back in the store.
                                    }
                                }
                                isEditing.toggle()
                            }
                        } label: {
                            Text(isNew ? "Adicionar" : (isEditing ? "OK" : "Editar"))
                        }
                    }
                }
                .onAppear {
                    topicCopy = topic // Grab a copy in case we decide to make edits.
                }
                .disabled(isTopicDeleted)

            if isEditing && !isNew {

                Button(role: .destructive, action: {
                    isDeleted = true
                    dismiss()
                    topicData.delete(topic)
                }, label: {
                    Label("Deletar tema", systemImage: "trash.circle.fill")
                        .font(.title2)
                        .foregroundColor(.red)
                })
                    .padding()
            }
        }
        .overlay(alignment: .center) {
            if isTopicDeleted {
                Color(UIColor.systemBackground)
                Text("Tema deletado.")
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct TopicEdit_Previews: PreviewProvider {
    static var previews: some View {
        TopicEdit(topic: .constant(Topic()))
    }
}
