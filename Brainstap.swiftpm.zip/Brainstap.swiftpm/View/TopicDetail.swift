//
//  TopicDetail.swift
//  Brainstap
//
//  Created by Milena Lima de Alcântara on 20/04/22.
//

import SwiftUI

struct TopicDetail: View {
    @Binding var topic: Topic
    let isEditing: Bool
    
    var body: some View {
        if isEditing {
            VStack {
                TextField("Novo tema", text: $topic.title)
                    .font(.title3)
            }
        } else {
            IdeaContent(topic: topic)
        }
    }
}

struct TopicDetail_Previews: PreviewProvider {
    static var previews: some View {
        TopicDetail(topic: .constant(Topic.example), isEditing: true)
    }
}
