//
//  Ideas.swift
//  
//
//  Created by Milena Lima de Alcântara on 20/04/22.
//

import SwiftUI

struct Ideas: View {
    @State private var bouncing = false
    var idea: String = "minha ideia aqui"
    
    var body: some View {
        Text(idea)
//        .fill(Color.green)
        .frame(width: 200, height: 200, alignment: .center)
//        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
        
//    maxHeight: .infinity, alignment: bouncing ? .bottom : .top
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            Ideas()
        }
    }
}
