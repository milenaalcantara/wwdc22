//
//  TopicList.swift
//  
//
//  Created by Milena Lima de Alcântara on 19/04/22.
//

import SwiftUI

struct TopicList: View {
    @EnvironmentObject var topicData: TopicData
    @State private var isAddingNewTopic = false
    @State private var newTopic = Topic()
    
    let topic: Topic
    
    var body: some View {
        List {
            ForEach(topicData.choiceTopic(topic: topic)) { $topic in
                NavigationLink{
                    TopicEdit(topic: $topic)
                        .navigationTitle(topic.title)
                } label: {
                    TopicRow(topic: topic)
                }
                .swipeActions {
                    Button(role: .destructive) {
                        topicData.delete(topic)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
        }
//        .navigationTitle("Temas")
        .toolbar {
            Button {
                newTopic = Topic()
                isAddingNewTopic = true
            } label: {
                Image(systemName: "plus")
            }
            .accessibilityLabel("Add new theme for brainstorm")
        }
        .sheet(isPresented: $isAddingNewTopic) {
            NavigationView {
                TopicEdit(topic: $newTopic, isNew: true)
            }
//            isAddingNewTopic = false
        }
    }
}

struct TopicList_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            TopicList(topic: Topic.example).environmentObject(TopicData())
        }
    }
}
