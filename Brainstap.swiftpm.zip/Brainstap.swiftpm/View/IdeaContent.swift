//
//  SwiftUIView.swift
//  
//
//  Created by Milena Lima de Alcântara on 20/04/22.
//

import SwiftUI

struct IdeaContent: View {
    
    var topic: Topic
    
    var body: some View {
        ZStack {
            ForEach(topic.ideas) { idea in //keypath
                HStack {
                    Spacer()
                        .frame(width: CGFloat.random(in: 0...UIScreen.main.bounds.width/2), height: CGFloat.random(in: 0...UIScreen.main.bounds.height/2))
                        .background(.blue.opacity(0.5))
        //                    BouncingView(text: "Hello")
                    BouncingView(text: idea.text)
                        .padding()
                        .lineLimit(1)

                    Spacer()
                        .frame(width: CGFloat.random(in: 0...UIScreen.main.bounds.width/2), height: CGFloat.random(in: 0...UIScreen.main.bounds.height/2))
                        .background(.red.opacity(0.5))
                }
            }
        }
    }
}

struct IdeaContent_Previews: PreviewProvider {
        
    static var previews: some View {
        NavigationView {
            IdeaContent(topic: Topic.example)
        }
    }
}

extension Color {
    static var random: Color {
        Color(
            red: Double.random(in: 0...1),
            green: Double.random(in: 0...1),
            blue: Double.random(in: 0...1)
        )
    }
}



//            Capsule()
//                .frame(minWidth: 10, idealWidth: 15, maxWidth: 20, minHeight: 8, idealHeight: 12, maxHeight: 16, alignment: .center)
